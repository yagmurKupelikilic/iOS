//
//  TeamsVC.swift
//  yagmurKupelikilic_midterm
//
//  Created by CTIS Student on 11.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class TeamsVC: UIViewController {
    
    
    @IBOutlet weak var besiktasImage: UIImageView!
    @IBOutlet weak var fenerbahceImage: UIImageView!
    @IBOutlet weak var galatsarayImage: UIImageView!
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? PlayerVC{
            
            if segue.identifier == "besiktas" {
                // Passing data to the PlayerVC
                vc.team = "besiktas"
            }else if segue.identifier == "fenerbahce"{
                vc.team = "fenerbahce"
            }else if segue.identifier == "galatasaray"{
                vc.team = "galatasaray"
            }else{
                vc.team = "All"
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        besiktasImage.isUserInteractionEnabled = true
        fenerbahceImage.isUserInteractionEnabled = true
        galatsarayImage.isUserInteractionEnabled = true
        // Do any additional setup after loading the view.
    }
}

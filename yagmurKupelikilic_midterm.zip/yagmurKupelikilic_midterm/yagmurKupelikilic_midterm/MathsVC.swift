//  MathsVC.swift
//  yagmurKupelikilic_midterm
//
//  Created by CTIS Student on 11.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class MathsVC: UIViewController {
    
    @IBOutlet weak var mNumber1: UITextField!
    @IBOutlet weak var mNumber2: UITextField!
    
    
    @IBAction func plusOnClick(_ sender: UIButton) {
        if mNumber1.text!.isEmpty && mNumber2.text!.isEmpty  {
            let num1: Double! = 0.0
            let num2 : Double! = 0.0
            let calculation:Double! = num1 + num2
            let result = String(format: "%0.2f + %0.2f = %0.2f " ,num1, num2, calculation)
            displayAlertDialog(header: "Output", msg: result )
        }
        else if mNumber1.text!.isEmpty || mNumber2.text!.isEmpty{
            displayAlertDialog(header: "Entered Data", msg: "Please enter both numbers ")
        }
        else{
            let num1 = Double(mNumber1.text!)!
            let num2 = Double(mNumber2.text!)!
            let calculation:Double! = num1 + num2
            let result = String(format: "%0.2f + %0.2f = %0.2f " , num1, num2, calculation)
            displayAlertDialog(header: "Output", msg: result)
        }
    }
    
    @IBAction func minusOnClick(_ sender: UIButton) {
        if mNumber1.text!.isEmpty && mNumber2.text!.isEmpty  {
            let result = String(format: "%0.2f - %0.2f = %0.2f " , 0, 0, 0)
            displayAlertDialog(header: "Output", msg: result )
        }
        else if mNumber1.text!.isEmpty || mNumber2.text!.isEmpty  {
            displayAlertDialog(header: "Entered Data", msg: "Please enter both numbers ")
        }else{
            let num1 = Double(mNumber1.text!)!
            let num2 = Double(mNumber2.text!)!
            let calculation:Double! = num1 - num2
            let result = String(format: "%0.2f - %0.2f = %0.2f " , num1, num2, calculation)
            displayAlertDialog(header: "Output", msg: result)
        }
    }
    
    @IBAction func multiplyOnClick(_ sender: UIButton) {
        if mNumber1.text!.isEmpty && mNumber2.text!.isEmpty  {
            let result = String(format: "%0.2f * %0.2f = %0.2f " , 0, 0, 0)
            displayAlertDialog(header: "Output ", msg: result )
        }else if mNumber1.text!.isEmpty || mNumber2.text!.isEmpty{
            displayAlertDialog(header: "Entered Data", msg: "Please enter both numbers ")
        }else{
            let num1 = Double(mNumber1.text!)!
            let num2 = Double(mNumber2.text!)!
            let calculation:Double! = num1 * num2
            let result = String(format: "%0.2f * %0.2f = %0.2f " , num1, num2, calculation)
            displayAlertDialog(header: "Output", msg: result)
        }
    }
    
    
    
    @IBAction func divideOnClick(_ sender: UIButton) {
        
        if mNumber1.text!.isEmpty && mNumber2.text!.isEmpty  {
            let result = String(format: "%0.2f / %0.2f = %0.2f " , 0.0, 1.0, 0.0)
            displayAlertDialog(header: "Output ", msg: result )
        }else if mNumber1.text!.isEmpty || mNumber2.text!.isEmpty{
            displayAlertDialog(header: "Entered Data", msg: "Please enter both numbers ")
        }else{
            let num1 = Double(mNumber1.text!)!
            let num2 = Double(mNumber2.text!)!
            let calculation:Double! = num1 / num2
            let result = String(format: "%0.2f / %0.2f = %0.2f " , num1, num2, calculation)
            displayAlertDialog(header: "Output", msg: result)
            mNumber1.text = ""
            mNumber2.text = ""
        }
        
    }
    
    func displayAlertDialog(header: String, msg: String){
        let mAlert = UIAlertController(title: header, message: msg, preferredStyle: .alert)
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        self.present(mAlert, animated: true, completion: nil)
        
    }
    
    
    // Clicking the view (the container for UI components) removes the Keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mNumber1.placeholder = "Please enter a number"
        mNumber2.placeholder = "Please enter a number"
    }
    
    
}

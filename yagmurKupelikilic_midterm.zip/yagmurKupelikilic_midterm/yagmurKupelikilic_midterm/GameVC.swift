//
//  GameVC.swift
//  yagmurKupelikilic_midterm
//
//  Created by CTIS Student on 12.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class GameVC: UIViewController {
    
    @IBOutlet var mImageViews: [UIImageView]!
    
    
    let mImages = ["mario","mini","pacman","sonic"]
    
    // Array to store randomly generated unique indexes 0..7 (set to Array)
    var indexArray = [Int]()
    
    // Array of UITapGestureRecognizer to attach to each UIImageView in the Collection Outlet
    var tapRecognizers = [UITapGestureRecognizer]()
    
    // Flag to create and attach UITapGestureRecognizer only one time to each UIImageView in the Collection
    var shouldCreateTapGesture = true
    
    @IBAction func onRearrangedButton(_ sender: UIButton) {
        var randomImageIndexSet = Set<Int>()
        var loopsCount = 0
        
        // Generating 8 unique random rumbers 0-7
        while randomImageIndexSet.count < 4 {
            let randomNumber = Int( arc4random_uniform( UInt32(mImages.count) ) )
            
            randomImageIndexSet.insert(randomNumber)
            
            // To determine number of times the while loop iterates (Only for our information)
            loopsCount += 1
        }
        //print(randomImageIndexSet)
        
        indexArray = Array(randomImageIndexSet)
        print(indexArray)
        
        // The above while loop code can be removed due to shuffled() function with slight modification
        // The code is only kept to explain the use of Set
        indexArray = indexArray.shuffled()
        print(indexArray)
        
        for x in 0..<mImageViews.count {
            //print(indexArray[x])
            mImageViews[x].image = UIImage(named: mImages[ indexArray[x] ])
            
        }
        
        if shouldCreateTapGesture {
            createTapGestures()
        }
    }
    
    func createTapGestures() {
        for x in 0..<mImageViews.count {
            tapRecognizers.append(UITapGestureRecognizer())
            // https://forums.developer.apple.com/thread/86081
            // clicking an image will fire a tapGeture and  tappedView() function will be called
            tapRecognizers[x].addTarget(self, action: #selector(GameVC.tappedView(_:)))
            mImageViews[x].addGestureRecognizer(tapRecognizers[x])
            mImageViews[x].isUserInteractionEnabled = true
            mImageViews[x].tag = x
        }
        
        shouldCreateTapGesture = false
    }
    
    @objc func tappedView(_ gesture: UITapGestureRecognizer) {
        print(indexArray[gesture.view!.tag])
        print(mImages[indexArray[gesture.view!.tag]])
        let images: String = mImages[indexArray[gesture.view!.tag]]
        let tapAlert = UIAlertController(title: "Image Clicked", message: images, preferredStyle: .alert)
        tapAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        self.present(tapAlert, animated: true, completion: nil)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
}

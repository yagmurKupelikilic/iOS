//
//  MHRVC.swift
//  yagmurKupelikilic_midterm
//
//  Created by CTIS Student on 10.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class MHRVC: UIViewController {
    
    @IBOutlet weak var mLabel: UILabel!
    @IBOutlet weak var ageText: UITextField!
    @IBOutlet weak var mSegmentedControl: UISegmentedControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ageText.placeholder = "Please enter your ages"
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func onSegmentedControl(_ sender: UISegmentedControl) {
        // switch sender.selectedSegmentIndex
        switch mSegmentedControl.selectedSegmentIndex   {
        case 0:
            mLabel.text = "Gender ( male ) : "
        default:
            mLabel.text = "Gender ( female ) : "
        }
    }
    
    
    func calculate(age: Int) -> Double {
        
        let out = 0.0
        if mSegmentedControl.selectedSegmentIndex == 0{
            let out = 203.7 / (1.0 + exp (0.033 * (Double(age) - 104.3)))
            return out
        }else{
            let out = 190.2 / (1.0 + exp(0.0453 * (Double(age) - 107.5)))
            return out
        }
        
        return out
    }
    
    @IBAction func onClick(_ sender: UIButton) {
        if ageText.text!.isEmpty  {
            displayAlertDialog(header: "Entered Data", msg: "Age cannot be empty! ")
        }else {
            let age = Double(ageText.text!)!
            let calculation = calculate(age: Int(Double(age)))
            let hr1 = calculation * 50 / 100
            let hr2 = calculation * 70 / 100
            let cr1 = calculation * 70 / 100
            let cr2 = calculation * 80 / 100
            let result = String(format: "MHR = %0.2f BPM\n Fat Burning HR range (%0.0f--%0.f)\n Cardiovascular HR range (%0.0f--%0.0f)", calculation, round(hr1), round(hr2), round(cr1), round(cr2))
            if(mSegmentedControl.selectedSegmentIndex == 0){
                displayAlertDialog(header: "Male output", msg: result)
                ageText.text = ""
            }else{
                displayAlertDialog(header: "Female output", msg: result)
                ageText.text = ""
            }
        }
    }
    
    func displayAlertDialog(header: String, msg: String){
        let mAlert = UIAlertController(title: header, message: msg, preferredStyle: .alert)
        mAlert.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
        self.present(mAlert, animated: true, completion: nil)
        
    }
    
    // Clicking the view (the container for UI components) removes the Keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

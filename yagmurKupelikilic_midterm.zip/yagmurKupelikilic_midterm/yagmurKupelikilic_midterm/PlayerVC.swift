//
//  PlayerVC.swift
//  yagmurKupelikilic_midterm
//
//  Created by CTIS Student on 11.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class PlayerVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var mTableView: UITableView!
    
    var team = ""
    var allPlayers = [(String, String, String)]()
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allPlayers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
        
        let (player, team, position) = allPlayers[indexPath.row]
        // Setting the data for the cell (optional chaining)
        cell.textLabel?.text = player
        cell.imageView?.image = UIImage(named: team)
        cell.detailTextLabel?.text = position
        
        return cell
    }
    
    
    func populateData(team: String) {
        
        if let path = Bundle.main.path(forResource: "players", ofType: "plist") {
            if let dictArray = NSArray(contentsOfFile: path) {
                for item in dictArray {
                    
                    if let dict = item as? NSDictionary {
                        if team ==  "All" {
                            allPlayers.append((dict.allValues[0] as! String, dict.allValues[2] as! String, dict.allValues[1] as! String))
                            print(dict.allValues[2] as! String)
                        }
                        else if (dict.allValues[2] as! String) == team {
                            
                            allPlayers.append(((dict.allValues[0] as! String), team, dict.allValues[1] as! String))
                            
                        }
                    }
                }
            }
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        populateData(team: team)
        //mTableView.reloadData()
        // Do any additional setup after loading the view.
    }
    
    
    
}

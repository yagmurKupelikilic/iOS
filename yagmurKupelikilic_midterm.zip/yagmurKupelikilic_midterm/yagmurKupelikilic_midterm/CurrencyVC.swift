//
//  CurrencyVC.swift
//  yagmurKupelikilic_midterm
//
//  Created by CTIS Student on 11.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class CurrencyVC: UIViewController {
    
    @IBOutlet weak var mImageView: UIImageView!
    @IBOutlet weak var mLabel: UILabel!
    @IBOutlet weak var mTextField1: UITextField!
    @IBOutlet weak var mTextField2: UITextField!
    @IBOutlet weak var mSegmentedControl: UISegmentedControl!
    @IBOutlet weak var mLabelTL: UILabel!
    @IBOutlet weak var mLabelUSD: UILabel!
    
    // var toggle = 0
    
    var USD = 6.7
    var EUR = 7.1
    
    //Switching from clicking on image via single tap gesture
    @IBAction func onClickImage(_ sender: UITapGestureRecognizer) {
        if mSegmentedControl.selectedSegmentIndex == 0 { // toggle = 0
            mSegmentedControl.selectedSegmentIndex = 1 // toggle = 1
            mImageView.image = UIImage(named: "tl_euro" )
            mLabel.text = "Euro ( \u{20AC} ) : "
            mTextField2.placeholder = "EURO( \u{20AC} ) :"
            mTextField1.text = ""
            mTextField2.text = ""
        }else{
            //  toggle = 0
            mSegmentedControl.selectedSegmentIndex = 0
            mImageView.image = UIImage(named: "tl_usd" )
            mLabel.text = "USD ( \u{0024} ) :"
            mTextField2.placeholder = "USD ( \u{0024} ) :"
            mTextField1.text = ""
            mTextField2.text = ""
        }
    }
    
    //Switching from segmented Control
    @IBAction func onSegmentedControl(_ sender: UISegmentedControl) {
        if mSegmentedControl.selectedSegmentIndex == 0{
            mImageView.image = UIImage (named: "tl_usd")
            mLabel.text = "USD ( \u{0024} ) :"
            mTextField2.placeholder = "Enter amount in ( \u{0024} ) :"
            mTextField1.text = ""
            mTextField2.text = ""
        }else{
            mImageView.image = UIImage(named: "tl_euro" )
            mLabel.text = "Euro ( \u{20AC} ) : "
            mTextField2.placeholder = "Enter amount in ( \u{20AC} ) :"
            mTextField1.text = ""
            mTextField2.text = ""
        }
    }
    
    func onTLConversion () -> Double {
        if ( mSegmentedControl.selectedSegmentIndex == 0){
            let result: Double = Double(mTextField1.text!)! / USD
            return result
        }else{
            let result: Double = Double(mTextField1.text!)! / EUR
            return result
        }
    }
    func onCurrencyConversion () -> Double {
        if ( mSegmentedControl.selectedSegmentIndex == 0){
            let result: Double = Double(mTextField2.text!)! * USD
            return result
        }else{
            let result: Double = Double(mTextField2.text!)! * EUR
            return result
        }
    }
    //to make TextFields empty when clicking on TextField1
    @IBAction func TLEditingDidBegin(_ sender: UITextField) {
        mTextField2.text = ""
        mTextField1.text = ""
    }
    //to make TextFields empty when clicking on TextField2
    @IBAction func CurrencyEditingBegin(_ sender: UITextField) {
        mTextField2.text = ""
        mTextField1.text = ""
    }
    
    @IBAction func editingChanged(_ sender: UITextField) {
        if(mTextField1.text! == ""){
            mTextField2.text = ""
        }else {
            let currency = onTLConversion()
            let output = String(format: "%0.2f", currency)
            mTextField2.text = output
        }
    }
    @IBAction func editingChangedForCurrency(_ sender: UITextField) {
        if(mTextField2.text! == ""){
            mTextField1.text = ""
        }else {
            let currency = onCurrencyConversion()
            let output = String(format: "%0.2f", currency)
            mTextField1.text = output
        }
    }
    
    
    // Clicking the view (the container for UI components) removes the Keyboard
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mImageView.isUserInteractionEnabled = true
        
        mLabelTL.text = " TL (\u{20BA})"
        mLabelUSD.text = "USD ( \u{0024} ) "
        mTextField1.placeholder = "TL (\u{20BA})"
        mTextField2.placeholder = "USD ( \u{0024} ) :"
    }
    
    
}

//
//  ViewController.swift
//  yagmurKupelikilic_midterm
//
//  Created by CTIS Student on 10.04.2020.
//  Copyright © 2020 ctis. All rights reserved.
//

import UIKit

class MainVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func unWind(_ sender: UIStoryboardSegue){
      }

}

